# ==============================================================================
# tests/testthat.R
# Entry point for testthat
# ==============================================================================

library(testthat)
library(ClusteringVariables)

test_check("ClusteringVariables")
